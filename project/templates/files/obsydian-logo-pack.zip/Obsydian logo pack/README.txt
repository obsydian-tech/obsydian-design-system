Obsydian logo pack

obsydian-lockup-on-light   the shard and the name, for white or light grounds (documents, invoices)
obsydian-lockup-on-dark    the same for black grounds (decks, social, the web)
obsydian-mark              the shard alone, for small spaces and avatars
obsydian-app-tile          the shard on its black tile, for app icons and favicons

Use the files as they are. Never redraw, recolour, stretch, rotate or outline the shard, never put it on a
gradient square, and never set the name in another font. Leave clear space around the lockup at least the
height of the shard. Smallest sizes: lockup 30mm or 120px wide; mark 6mm or 20px.

More: https://obsydian-tech.github.io/obsydian-design-system/#brand
